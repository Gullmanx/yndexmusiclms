package Plugins::YandexMusic::Plugin;
use strict;
use warnings;

use Slim::Utils::Log;
use Slim::Utils::Prefs;
use LWP::UserAgent;
use JSON;

my $log = Slim::Utils::Log->addLogCategory({
    category    => 'yandexmusic',
    defaultLevel => 'INFO',
    description => 'Yandex Music Plugin'
});

my $prefs = preferences('plugin.yandexmusic');

sub setToken {
    my ($client, $token) = @_;
    $prefs->set('api_token', $token);

    my $ua = LWP::UserAgent->new;
    my $response = $ua->post('http://localhost:5000/set_token', Content => encode_json({ token => $token }));

    if ($response->is_success) {
        $log->info("API-ключ обновлён!");
    } else {
        $log->error("Ошибка обновления API-ключа: " . $response->status_line);
    }
}

sub getStreamUrl {
    my ($track_id) = @_;
    my $url = "http://localhost:5000/get_stream?track_id=$track_id";

    my $ua = LWP::UserAgent->new;
    my $response = $ua->get($url);

    if ($response->is_success) {
        my $data = decode_json($response->decoded_content);
        return $data->{'stream_url'};
    } else {
        $log->error("Ошибка при получении ссылки: " . $response->status_line);
        return undef;
    }
}

sub getPlaylistTracks {
    my ($playlist_id) = @_;
    my $url = "http://localhost:5000/get_playlist?playlist_id=$playlist_id";

    my $ua = LWP::UserAgent->new;
    my $response = $ua->get($url);

    if ($response->is_success) {
        my $data = decode_json($response->decoded_content);
        return $data->{'tracks'};
    } else {
        $log->error("Ошибка при получении плейлиста: " . $response->status_line);
        return [];
    }
}

sub playTrack {
    my ($client, $track_id) = @_;
    my $stream_url = getStreamUrl($track_id);
    return unless $stream_url;

    $client->execute(['playlistcontrol', 'cmd:add', "url:$stream_url"]);
    $client->execute(['play']);
}

sub playPlaylist {
    my ($client, $playlist_id) = @_;
    my $tracks = getPlaylistTracks($playlist_id);
    
    foreach my $track (@$tracks) {
        $client->execute(['playlistcontrol', 'cmd:add', "url:$track->{'url'}"]);
    }
    $client->execute(['play']);
}

sub initPlugin {
    my $class = shift;
    
    Slim::Control::Request::addDispatch(['yandexmusic', 'play', ':track_id'], [1, 1, 1, \&playTrack]);
    Slim::Control::Request::addDispatch(['yandexmusic', 'playlist', ':playlist_id'], [1, 1, 1, \&playPlaylist]);
    Slim::Control::Request::addDispatch(['yandexmusic', 'set_token', ':token'], [1, 1, 1, \&setToken]);

    $log->info("Плагин Yandex Music загружен!");
}

sub shutdownPlugin {
    $log->info("Плагин Yandex Music выгружен!");
}

1;
