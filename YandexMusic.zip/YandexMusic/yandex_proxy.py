from flask import Flask, request, jsonify
from yandex_music import Client

app = Flask(__name__)

# Здесь храним API-ключ
YANDEX_TOKEN = None
client = None

def init_client():
    global client
    if YANDEX_TOKEN:
        client = Client(YANDEX_TOKEN).init()

@app.route('/set_token', methods=['POST'])
def set_token():
    global YANDEX_TOKEN
    YANDEX_TOKEN = request.json.get('token')
    init_client()
    return jsonify({"status": "success", "message": "Token updated"})

@app.route('/get_stream', methods=['GET'])
def get_stream():
    if not client:
        return jsonify({'error': 'No API token set'}), 400

    track_id = request.args.get('track_id')
    if not track_id:
        return jsonify({'error': 'No track_id provided'}), 400

    try:
        track = client.tracks(track_id)[0]
        stream_url = track.get_download_info()[0].get_direct_link()
        return jsonify({'stream_url': stream_url})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/get_playlist', methods=['GET'])
def get_playlist():
    if not client:
        return jsonify({'error': 'No API token set'}), 400

    playlist_id = request.args.get('playlist_id')
    if not playlist_id:
        return jsonify({'error': 'No playlist_id provided'}), 400

    try:
        playlist = client.users_playlists(playlist_id=playlist_id)
        tracks = []
        for track in playlist.tracks:
            track_data = track.fetch_track()
            stream_url = track_data.get_download_info()[0].get_direct_link()
            tracks.append({'title': track_data.title, 'url': stream_url})
        return jsonify({'tracks': tracks})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
